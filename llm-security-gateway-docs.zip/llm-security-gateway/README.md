# LLM Security Gateway

**Team Vantage · Hackatopia 2026 · Problem CB-01: LLM firewall against prompt injection**

AI assistants connected to email, documents and tools can be hijacked by instructions hidden in a web page, PDF or email. This project is a general security gateway that sits in front of any LLM app. It finds and removes hidden attacks, limits what the AI is allowed to do, and checks everything the AI says before it reaches the user.

## How it works

```
User / PDF / Web page / Email
            |
   GUARD A  (steps 1-7)  checks what goes in, hides risky tools
            |
        LLM (Gemini)
            |
   GUARD B  (steps 8-9)  checks every tool call and the reply
            |
   Step 10 logs everything  ->  Console shows each decision
```

## Main features

- Hidden-text extraction from PDFs, web pages and emails
- Per-chunk risk scoring with rules and a pretrained classifier
- Cleans only the malicious part, keeps the rest
- Hides risky tools when untrusted content is present
- Policy engine on every tool call (allow-list, approved domains, taint rule, goal check, approval)
- Output firewall (canary tripwire, link and image stripping, personal data and secret redaction)
- Audit log with reasons and timings
- Web console showing the full pipeline live
- Company-specific rules in YAML profiles

## Quick start

See `docs/SETUP.md`. In short:

```bash
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env        # add GEMINI_API_KEY
uvicorn app.main:app --reload
# open http://localhost:8000
```

## Documentation

Start with `CLAUDE.md`, then the `docs/` folder.

## Limits

No system stops every attack. See `docs/THREAT_MODEL.md` for what is covered and what is not. All data in this project is fake.
